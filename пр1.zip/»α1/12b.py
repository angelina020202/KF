import math
r = float(input('Введите точку r: ')) 
pl = 10* 10**-6
R0 = 0.01
E0 = 8.85*10**-12
k0 = 1 / (4*math.pi*E0) 
Fr = (4*k0*math.pi*pl*R0**2) / r
print("Потенциал поля в точке r = ",Fr)