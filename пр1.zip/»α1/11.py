import math
x = int(input('Введите угол в градусах: ')) 
print(math.cos(x*math.pi/180))