import math
pl = 10* 10**-6
r1 = 0.1
R0 = 0.01
E0 = 8.85*10**-12
k0 = 1 / (4*math.pi*E0) 
Fr1 = (4*k0*math.pi*pl*R0**2) / r1
print("Потенциал поля в точке r1 = ",Fr1)