import matplotlib.pyplot as plt
from numpy import arange

q1 = 20
q2 = 30

x = []
y = []

for r in arange(2, 10, 0.5):
    F = (q1 * q2) / (r ** 2)
    x.append(r)
    y.append(F)

print('E = ', round(F, 2))

plt.plot(x, y)
plt.show()