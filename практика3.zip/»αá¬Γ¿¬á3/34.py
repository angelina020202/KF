import matplotlib.pyplot as plt
import numpy as np 
x = np.linspace(0, 5, 10)
y = np.e**x
fig = plt.figure(facecolor='white')
ax1 = fig.add_axes([0.1,0.1,0.8,0.8])
ax2 = fig.add_axes([0.2, 0.5, 0.4, 0.3])
ax1.plot(x, y, 'r', linewidth = 3)
ax1.set_title('График функции $e^{x}$')
ax2.plot(y, x, 'g', linewidth=3)
ax2.set_xlabel('y')
ax2.set_xlabel('x')
ax2.set_title('ln y')
plt.show()