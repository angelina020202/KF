import matplotlib.pyplot as plt
import numpy as np 
Q=int(input("Введите Q:"))
l=int(input("Введите L:"))
print("Введите Q")
x = []
y = []

for r in range(1,20):
    e0 = 8.85*10**-12
    E = (1/(4*np.pi*e0))*2*Q*l/(r**3)
    x.append(r)
    y.append(E)

print("E = ", E)
plt.plot(x, y)
plt.show()