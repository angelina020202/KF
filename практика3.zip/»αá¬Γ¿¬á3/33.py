import matplotlib.pyplot as plt
import numpy as np
x=np.linspace(0,40*np.pi,600)
plt.axes().set_aspect(10)
plt.plot(x,np.sin(x),'-r', linewidth=5, label=r'$\sin x$')
plt.title(r'$\sin x$', fontsize=20)
plt.show()