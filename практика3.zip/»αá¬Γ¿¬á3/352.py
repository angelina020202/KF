import matplotlib.pyplot as plt
import numpy as np
t=np.linspace(-8*np.pi,8*np.pi,400)
rt1=np.e**np.sin(t)
rt2=2*np.cos(4*t)
rt3=np.sin((2*t-np.pi)/24)**5
rt= rt1 - rt2 + rt3
plt.polar(t,rt,
          linewidth=4, color='blue')