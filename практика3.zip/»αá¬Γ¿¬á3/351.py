import matplotlib.pyplot as plt
import numpy as np
t=np.linspace(0,8*np.pi,400)
plt.polar(t,(np.sin((7/4)*t)),
          linewidth=4, color='blue')