import matplotlib.pyplot as plt
import numpy as np
t=np.linspace(0,20*np.pi,700)
x = 6.2*(np.cos(t)-(np.cos(3.1*t)/3.1))
y = 6.2*(np.sin(t)-(np.sin(3.1*t)/3.1))
plt.plot(x,y,linewidth=2, color='red')
plt.show()
