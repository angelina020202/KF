import matplotlib.pyplot as plt
import numpy as np
x=np.linspace(-3,3,51)
y1=(x**2)*np.e**(-x**2)
y2=x*np.e**(-x**2)
plt.plot(x, y1, 'v-', linewidth=3, label=r'f1(x)',markersize=6)
plt.plot(x, y2, 'r-', linewidth=2, label=r'f2(x)',markersize=6)
plt.legend(fontsize=12, loc='best')
plt.title(r'f1(x), f2(x)', fontsize=20)
plt.show()