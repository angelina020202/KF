import matplotlib.pyplot as plt
import numpy as np
x=np.linspace(-3,3,51)
y=2/x
y1=np.sqrt(x)
y2=-x**2
plt.plot(x,y , 'b-o', linewidth=2, label=r'2/x' ,markersize=6)
plt.plot(x, y1, 'm*', linewidth=2, label=r'sqrt(x)',markersize=6)
plt.plot(x, y2, 'r-+', linewidth=2, label=r'-x^2',markersize=6)
plt.legend(fontsize=12, loc='best')
plt.title(r'2/x, sqrt(x), -x^2', fontsize=20)
plt.show()