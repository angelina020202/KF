import math
Q1=2 * 10 ** -9
Q2=-3 * 10 ** -9
l=20 / 100
e0=8.85 * (10 ** -12)

r1 = int(input('Введите r1: '))
r2 = int(input('Введите r2: '))
r1 = r1 / 100
r2 = r2 / 100

b = - ((l ** 2) - (r1 ** 2) - (r2 ** 2)) / (2 * r1 * r2)
E = 1 / (4 * math.pi * e0) * math.sqrt(((Q1 ** 2) / (r1 ** 4)) + ((Q2 ** 2) / (r2 ** 4)) - (
    (2 * math.fabs(Q1) * math.fabs(Q2)) / ((r1 ** 2) * (r2 ** 2))) * b)

print('E =', math.ceil(E / 1000), 'кВ/м')