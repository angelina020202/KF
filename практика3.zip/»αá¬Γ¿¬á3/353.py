import matplotlib.pyplot as plt
import numpy as np
t=np.linspace(0,20*np.pi,800)
x = 4.4*(np.cos(t) +( np.cos(1.1*t)/1.1))
y = 4.4*(np.sin(t)-(np.sin(1.1*t)/1.1))
plt.plot(x,y,linewidth=2, color='black')
plt.show()