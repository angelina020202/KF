import numpy as np
q1=20
q2=30
E0=8.85*(10**-12)
r=[2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10]
for i in range(len(r)):
    print(r[i])
    E=((q1*q2)/(4*np.pi*E0*r^2))
    print( E[i])
