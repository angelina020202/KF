import numpy as np
A = np.array([[1, 2, 3, 4], 
               [2, 2, -4, 5]]);
B = np.array([[1, 1, 1, 2], 
               [2, 3, 5, 6]]);
a=3
b=4
#A1= np.dot(a, A)
A1=a*A
#B1= np.dot(b, B)
B1=b*B
C=A1-B1
R= C
min=np.amin(C)
print('\n Результат: \n', C)
print("Минимальный элемент:", min)
