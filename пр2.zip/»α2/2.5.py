import numpy as np
A = np.array([[1, 2], 
               [3, 4]]);
B=np.array([[8, 1],
            [18, -1]]);
x=B/A
print('X = \n', x)