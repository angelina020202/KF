import numpy as np
list1 = [1, 2, 3]
list2= [[4],
        [5],
        [6]]
 
lt=np.transpose(list2)
print(lt)
vtr = list1+lt
print("Результат: ",vtr) 