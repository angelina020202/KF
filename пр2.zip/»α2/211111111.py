import numpy as np
n = int(input('Введите размер матриц: ')) 
a = []
b=[]
for i in range(n):
    for j in range(n):
        print("A[", i," ",j, "]=", end='')
        a.append(list(map(int, input().split())))
        print("B[", i," ",j, "]=", end='')
        b.append(list(map(int, input().split())))
print("Элементы матрицы А = ", a)
print("Элементы матрицы В = ", b)
m1 = np.array(a).reshape(n,n) 
m2 = np.array(b).reshape(n,n) 
c = m1 + m2
print("Сумма двух матриц = ",c)
print('Определитель первой матрицы:',np.linalg.det(m1))
print('Сумма диагоналей первой матрицы:',np.trace(m1))
D = m1 - m2
print("Разность матриц:\n" , D)
w,v = np.linalg.eig(m1)
print("Собственные числа:\n", w)
print("Собственные векторы:\n", v)
E = np.multiply(m1,m2)
print("Произведение матриц:\n" , E)  



