import numpy as np
A = np.array([[2, -4], 
               [3, 5],
               [-1, 0]]);
B = np.array([[1, 2, 7],
              [-3, -4, 0],
               [5, 2, 1]]);
C = np.array([[6, -3, 9],
              [4, -5, 2],
               [8, 1, 5]]);
At=A.transpose()
Bt=B.transpose()
AC=At.dot(C)
A2=2*At
A2B=A2.dot(Bt)
D=AC-A2B
min=np.amin(D)
print('\n D:', D)
print("Минимальный элемент:", min)