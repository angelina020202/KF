import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(-1.0,1.0,51)
print(x)
y= np.linspace(-1.0,1.0,51)
print(y)
X,Y=np.meshgrid(x,y)
print(X)
print(Y)
Z=1-X**2-Y**2
Z[Z<0]=0
Z=np.sqrt(Z)
fig = plt.figure()
ax = fig.add_subplot(111, projection = '3d')
ax.plot_surface(X,Y, Z, rstride=1, cstride = 1)
plt.show()
 