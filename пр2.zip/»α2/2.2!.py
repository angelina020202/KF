import numpy as np
b = np.array([[7, -3, -1],
               [2, 7, 0],
               [-5, 1, -2]]);
print(b)
c = b < 0
print(c)
d = b[c]
print('Pезультат:' ,d)